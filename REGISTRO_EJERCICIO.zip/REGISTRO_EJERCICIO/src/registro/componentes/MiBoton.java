/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro.componentes;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;

/**
 *
 * @author Pablo
 */
public class MiBoton extends JButton implements MouseListener{

    public MiBoton() {
        super();
        
        this.setFont(new java.awt.Font("Nirmala UI",Font.BOLD,18));
        this.setForeground(Color.white);
        this.setBackground(new java.awt.Color(82, 217, 107));
        this.setBorder(null);
        addMouseListener(this);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        this.setBackground(new java.awt.Color(75,163,252));
        this.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    @Override
    public void mouseExited(MouseEvent e) {
        this.setBackground(new java.awt.Color(82, 217, 107));
        this.setCursor(new Cursor(Cursor.MOVE_CURSOR));
    }
    
}
