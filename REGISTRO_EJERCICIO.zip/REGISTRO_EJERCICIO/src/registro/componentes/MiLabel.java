/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro.componentes;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

/**
 *
 * @author Pablo
 */
public class MiLabel extends JLabel{

    public MiLabel() {
        super();
        setFont(new Font("Nirmala UI",Font.BOLD,14));
        setForeground(Color.BLACK);
        setBackground(Color.white);
    }
}
