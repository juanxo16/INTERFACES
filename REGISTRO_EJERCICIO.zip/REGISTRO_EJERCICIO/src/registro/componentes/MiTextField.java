/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro.componentes;

import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

/**
 *
 * @author Pablo
 */
public class MiTextField extends JTextField implements FocusListener {

    public MiTextField() {
        super();
        this.setFont(new java.awt.Font("Nirmala UI",0,14));
        this.setForeground(Color.BLACK);
        this.setBackground(Color.LIGHT_GRAY);
        this.setBorder(new LineBorder(Color.GRAY,2));
        addFocusListener(this);
    }
    @Override
    public void focusGained(FocusEvent e) {
        this.setBorder(new LineBorder(Color.GREEN,2));
        this.setBackground(Color.WHITE);
    }

    @Override
    public void focusLost(FocusEvent e) {
        this.setBorder(new LineBorder(Color.GRAY,2));
        this.setBackground(Color.LIGHT_GRAY);
    }

}
