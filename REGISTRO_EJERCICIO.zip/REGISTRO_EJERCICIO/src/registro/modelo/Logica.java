/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro.modelo;

import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class Logica {
    private ArrayList<Usuario> listaUsuarios = new ArrayList<>();
    private ArrayList<String> listaNombreUsuario = new ArrayList<>();
    private ArrayList<String> listaEmails = new ArrayList<>();

    public Logica() {
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(ArrayList<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public ArrayList<String> getListaNombreUsuario() {
        return listaNombreUsuario;
    }

    public void setListaNombreUsuario(ArrayList<String> listaNombreUsuario) {
        this.listaNombreUsuario = listaNombreUsuario;
    }

    public ArrayList<String> getListaEmails() {
        return listaEmails;
    }

    public void setListaEmails(ArrayList<String> listaEmails) {
        this.listaEmails = listaEmails;
    }

   
    
    public void addUsuario(Usuario usuario){
        listaUsuarios.add(usuario);
        listaNombreUsuario.add(usuario.getUsuario());
        listaEmails.add(usuario.getEmail());
    }
}
