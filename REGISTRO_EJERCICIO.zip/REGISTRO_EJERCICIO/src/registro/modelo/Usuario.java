/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro.modelo;

import javax.swing.Icon;

/**
 *
 * @author Juan
 */
public class Usuario {
    private String usuario;
    private String contrasenia;
    private String email;
    private String nombre;
    private String apellidos;
    private String sexo;
    private String nacionalidad;
    private String telefono;
    private Icon fotoPerfil;
    private String fechaNacimiento;

    public Usuario() {
    }
    
    public Usuario(String usario, String contrasenia, String email, String nombre, String apellidos, String sexo, String nacionalidad, String telefono, Icon fotoPerfil, String fechaNacimiento) {
        this.usuario = usario;
        this.contrasenia = contrasenia;
        this.email = email;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.sexo = sexo;
        this.nacionalidad = nacionalidad;
        this.telefono = telefono;
        this.fotoPerfil = fotoPerfil;
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Icon getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(Icon fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

   
}
